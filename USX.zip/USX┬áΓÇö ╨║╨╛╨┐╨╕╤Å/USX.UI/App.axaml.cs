using System.Linq;
using Avalonia.Controls.ApplicationLifetimes;
using Avalonia.Markup.Xaml;
using Microsoft.EntityFrameworkCore;
using USX.Application;
using USX.Application.Entities;
using USX.UI.ViewModels;
using USX.UI.Views;

namespace USX.UI;

public partial class App : Avalonia.Application
{
    public override void Initialize()
    {
        AvaloniaXamlLoader.Load(this);
    }

    public override void OnFrameworkInitializationCompleted()
    {
        if (ApplicationLifetime is IClassicDesktopStyleApplicationLifetime desktop)
        {
            Category[] categories;
            using (var dbContext = new UsxDbContext())
            {
                categories = dbContext.Categories
                    .Include(x => x.Childrens)
                    .ThenInclude(x => x.Tasks)
                    .ToArray();
            }

            desktop.MainWindow = new MainWindow
            {
                DataContext = new MainWindowViewModel(categories, new TestGenerator())
            };
        }

        base.OnFrameworkInitializationCompleted();
    }
}
