using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using Avalonia.Controls;
using Spire.Doc;
using Spire.Doc.Documents;
using USX.Application;
using USX.Application.Entities;
using USX.UI.Views;
using Category = USX.UI.Models.Category;
using CategoryDb = USX.Application.Entities.Category;

namespace USX.UI.ViewModels;

public class MainWindowViewModel : ViewModelBase
{
    private readonly TestGenerator _testGenerator;

    public MainWindowViewModel(IEnumerable<CategoryDb> categories, TestGenerator testGenerator)
    {
        _testGenerator = testGenerator ?? throw new ArgumentNullException(nameof(testGenerator));
        Categories = new ObservableCollection<Category>(categories.Select(cdb => new Category(cdb)));
    }

    public ObservableCollection<Category> Categories { get; private init; }

    public async Task GeneratedTestCommand()
    {
        var testParams = Categories
            .Where(x => x.Value > 0)
            .Select(x => new TestParams(x.Id, x.Children.Where(y => y.IsAdd).Select(y => y.Id).ToArray(), x.Value))
            .ToArray();

        if (!testParams.Any())
        {
            return;
        }

        var dialog = new SaveFileDialog
        {
            Filters = new()
            {
                new FileDialogFilter
                {
                    Name = "Word",
                    Extensions = new List<string> { "docx" }
                }
            }
        };

        var result = await dialog.ShowAsync(new MainWindow());
        if (result is null)
        {
            return;
        }

        var files = await _testGenerator.GenTasksByParams(testParams);

        var newDoc = new Document();

        foreach (var file in files)
        {
            var doc = new Document();
            doc.LoadFromFile(file, FileFormat.Docx);

            foreach (Section sec in doc.Sections)
            {
                sec.BreakCode = SectionBreakType.NoBreak;
                newDoc.Sections.Add(sec.Clone());

                var section = newDoc.AddSection();
                section.BreakCode = SectionBreakType.NoBreak;
            }
        }

        newDoc.SaveToFile(result, FileFormat.Docx);
    }
}
