using ReactiveUI;

namespace USX.UI.ViewModels;

public class ViewModelBase : ReactiveObject
{
}
