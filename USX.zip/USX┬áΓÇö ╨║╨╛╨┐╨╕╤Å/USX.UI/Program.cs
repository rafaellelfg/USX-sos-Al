﻿using Avalonia;
using System;
using System.IO;
using Avalonia.ReactiveUI;
using Microsoft.EntityFrameworkCore;
using USX.Application;

namespace USX.UI;

class Program
{
    // Initialization code. Don't use any Avalonia, third-party APIs or any
    // SynchronizationContext-reliant code before AppMain is called: things aren't initialized
    // yet and stuff might break.
    [STAThread]
    public static void Main(string[] args)
    {
        Directory.CreateDirectory("UsxTasks");

        using (var dbContext = new UsxDbContext())
        {
            dbContext.Database.Migrate();
        }

        BuildAvaloniaApp().StartWithClassicDesktopLifetime(args);
    }

    // Avalonia configuration, don't remove; also used by visual designer.
    public static AppBuilder BuildAvaloniaApp()
        => AppBuilder.Configure<App>()
            .UsePlatformDetect()
            .LogToTrace()
            .UseReactiveUI();
}
