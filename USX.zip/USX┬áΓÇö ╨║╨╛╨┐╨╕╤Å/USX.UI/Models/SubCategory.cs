using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Avalonia.Controls;
using ReactiveUI;
using USX.Application;
using USX.Application.Entities;
using USX.UI.Views;
using SubCategoryDb = USX.Application.Entities.SubCategory;

namespace USX.UI.Models;

public sealed class SubCategory : ReactiveObject
{
    public SubCategory(SubCategoryDb subCategory)
    {
        ArgumentNullException.ThrowIfNull(subCategory);
        _subCategory = subCategory;
        Id = subCategory.Id;
        Name = subCategory.Name;
        Count = subCategory.Tasks.Count;
        IsAdd = true;
        IdView = $"{subCategory.ParentId}.{subCategory.DisplayId}";
    }

    private SubCategoryDb _subCategory;
    private bool _isAdd;

    public int Id { get; }
    public string IdView { get; }
    public string Name { get; }
    public int Count { get; private set; }
    public string CountView => $"{Count} шт.";

    public bool IsAdd
    {
        get => _isAdd;
        set => this.RaiseAndSetIfChanged(ref _isAdd, value);
    }

    public async Task AddTaskCommand()
    {
        var dialog = new OpenFileDialog
        {
            Filters = new()
            {
                new FileDialogFilter
                {
                    Name = "Word",
                    Extensions = new List<string> { "docx" }
                }
            },
            AllowMultiple = true
        };

        var results = await dialog.ShowAsync(new MainWindow());
        if (results is null || !results.Any())
        {
            return;
        }

        var tasks = new List<UsxTask>(results.Length);
        foreach (var result in results)
        {
            var newPath = Path.Join("./UsxTasks", $"{Guid.NewGuid():N}.docx");
            File.Copy(result, newPath);

            tasks.Add(new UsxTask(newPath, _subCategory));
        }

        await using (var dbContext = new UsxDbContext())
        {
            dbContext.UsxTasks.AddRange(tasks);
            await dbContext.SaveChangesAsync();
        }

        Count += results.Length;
        this.RaisePropertyChanged(nameof(Count));
        this.RaisePropertyChanged(nameof(CountView));
    }
}
