using System.Collections.ObjectModel;
using System.Linq;
using ReactiveUI;
using CategoryDb = USX.Application.Entities.Category;

namespace USX.UI.Models;

public sealed class Category : ReactiveObject
{
    public Category(CategoryDb model)
    {
        Id = model.Id;
        Name = model.Name;
        Value = 0;
        _isAdd = true;
        Children = new ObservableCollection<SubCategory>(model.Childrens.Select(cdb => new SubCategory(cdb)));
        foreach (var children in Children)
        {
            children.PropertyChanged += (_, args) =>
            {
                if (args.PropertyName == nameof(SubCategory.IsAdd))
                {
                    if (Children.All(c => c.IsAdd))
                    {
                        _isAdd = true;
                    }
                    else if (Children.All(c => !c.IsAdd))
                    {
                        _isAdd = false;
                    }
                    else
                    {
                        _isAdd = null;
                    }

                    this.RaisePropertyChanged(nameof(IsAdd));
                    this.RaisePropertyChanged(nameof(Count));
                    this.RaisePropertyChanged(nameof(CountView));
                }
                else if (args.PropertyName == nameof(SubCategory.Count))
                {
                    this.RaisePropertyChanged(nameof(Count));
                    this.RaisePropertyChanged(nameof(CountView));
                }
            };
        }
    }

    private bool? _isAdd;

    public int Id { get; }
    public string? Name { get; }
    public int Value { get; set; }

    public bool? IsAdd
    {
        get => _isAdd;
        set
        {
            if (value.HasValue)
            {
                foreach (var children in Children)
                {
                    children.IsAdd = value.Value;
                }
            }

            _isAdd = value;

            this.RaisePropertyChanged(nameof(Count));
            this.RaisePropertyChanged(nameof(CountView));
        }
    }

    public int Count => Children.Where(x => x.IsAdd).Sum(x => x.Count);
    public string CountView => $"{Count} шт.";
    public ObservableCollection<SubCategory> Children { get; init; }
}
