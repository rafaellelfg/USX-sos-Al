using Microsoft.EntityFrameworkCore;
using USX.Application.Entities;

namespace USX.Application;

public class TestGenerator
{
public async Task<IReadOnlyList<string>> GenTasksByParams(IReadOnlyCollection<TestParams> testParams)
{
    UsxTask[] usxTasks;
    await using (var usxDbContext = new UsxDbContext())
    {
        var subCategoryIds = testParams.SelectMany(x => x.SubCategoryIds).ToArray();
        usxTasks = await usxDbContext.UsxTasks.Where(t => subCategoryIds.Contains(t.CategoryId)).ToArrayAsync();
    }

    return testParams
        .SelectMany(p => usxTasks
            .Where(t => p.SubCategoryIds.Contains(t.CategoryId))
            .OrderBy(_ => Guid.NewGuid())
            .Take(p.Count))
        .Select(t => t.Path)
        .ToArray();
}
}
