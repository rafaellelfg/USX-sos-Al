﻿namespace USX.Application.Entities;

public sealed class UsxTask
{
    public UsxTask(string path, SubCategory category)
    {
        Id = Guid.NewGuid();
        Path = path;
        CategoryId = category.Id;
    }

    private UsxTask()
    {
    }

    public Guid Id { get; private init; }
    public int CategoryId { get; private init; }
    public string Path { get; private init; } = null!;
}
