namespace USX.Application.Entities;

public sealed class SubCategory
{
    private SubCategory()
    {
    }

    public int Id { get; private init; }
    public int DisplayId { get; private init; }
    public int ParentId { get; private init; }
    public string Name { get; private init; } = null!;
    public IReadOnlyCollection<UsxTask> Tasks { get; set; } = null!;
}
