namespace USX.Application.Entities;

public sealed class Category
{
    private Category()
    {
    }

    public int Id { get; private init; }
    public string Name { get; private init; } = null!;
    public IReadOnlyCollection<SubCategory> Childrens { get; private init; } = new List<SubCategory>();
}
