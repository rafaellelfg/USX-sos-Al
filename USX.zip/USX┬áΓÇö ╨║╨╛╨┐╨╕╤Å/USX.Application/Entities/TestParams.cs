namespace USX.Application.Entities;

public class TestParams
{
    public TestParams(int categoryId, IReadOnlyCollection<int> subCategoryIds, int count)
    {
        CategoryId = categoryId;
        SubCategoryIds = subCategoryIds;
        Count = count;
    }

    public int CategoryId { get; }
    public IReadOnlyCollection<int> SubCategoryIds { get; }
    public int Count { get; }
}
