using Microsoft.EntityFrameworkCore;
using USX.Application.Entities;

namespace USX.Application;

public class UsxDbContext : DbContext
{
    private readonly string _dbPath;

    public UsxDbContext()
    {
        _dbPath = Path.Join("./UsxTasks", "usx.db");
        Console.WriteLine(_dbPath);
    }

    public DbSet<Category> Categories => Set<Category>();
    public DbSet<SubCategory> SubCategories => Set<SubCategory>();
    public DbSet<UsxTask> UsxTasks => Set<UsxTask>();

    protected override void OnConfiguring(DbContextOptionsBuilder options)
        => options.UseSqlite($"Data Source={_dbPath}");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        BuildCategory(modelBuilder);
        BuildSubCategory(modelBuilder);
        BuildUsxTask(modelBuilder);
    }

    private static void BuildUsxTask(ModelBuilder modelBuilder)
    {
        modelBuilder
            .Entity<UsxTask>()
            .HasKey(x => x.Id);

        modelBuilder
            .Entity<UsxTask>()
            .HasOne<SubCategory>()
            .WithMany(x => x.Tasks)
            .HasForeignKey(x => x.CategoryId);
    }

    private static void BuildSubCategory(ModelBuilder modelBuilder)
    {
        modelBuilder
            .Entity<SubCategory>()
            .HasKey(x => x.Id);

        modelBuilder
            .Entity<SubCategory>()
            .Property(x => x.Id)
            .ValueGeneratedOnAdd();

        modelBuilder
            .Entity<SubCategory>()
            .HasOne<Category>()
            .WithMany(x => x.Childrens)
            .HasForeignKey(x => x.ParentId);

        var i = 1;
        var subCategory = new object[]
        {
            new { Id = ++i, DisplayId = 1, ParentId = 1, Name = "Траты" },
            new { Id = ++i, DisplayId = 2, ParentId = 1, Name = "Округление с избытком " },
            new { Id = ++i, DisplayId = 3, ParentId = 1, Name = "Округление с недостатком " },
            new { Id = ++i, DisplayId = 4, ParentId = 1, Name = "Переводы величин" },
            new { Id = ++i, DisplayId = 1, ParentId = 2, Name = "Задачи на проценты" },
            new { Id = ++i, DisplayId = 1, ParentId = 3, Name = "Графики" },
            new { Id = ++i, DisplayId = 2, ParentId = 3, Name = "Диаграммы" },
            new { Id = ++i, DisplayId = 1, ParentId = 4, Name = "Работа с формулами" },
            new { Id = ++i, DisplayId = 1, ParentId = 5, Name = "Треугольник" },
            new { Id = ++i, DisplayId = 2, ParentId = 5, Name = "Трапеция" },
            new { Id = ++i, DisplayId = 3, ParentId = 5, Name = "Параллелограмм" },
            new { Id = ++i, DisplayId = 4, ParentId = 5, Name = "Круг" },
            new { Id = ++i, DisplayId = 5, ParentId = 5, Name = "Произвольный четырехугольник" },
            new { Id = ++i, DisplayId = 6, ParentId = 5, Name = "Отрезок" },
            new { Id = ++i, DisplayId = 7, ParentId = 5, Name = "Тригонометрические функции" },
            new { Id = ++i, DisplayId = 1, ParentId = 6, Name = "Классическое определение теории вероятностей" },
            new { Id = ++i, DisplayId = 2, ParentId = 6, Name = "Применение теорем" },
            new { Id = ++i, DisplayId = 1, ParentId = 7, Name = "Квадратные уравнения" },
            new { Id = ++i, DisplayId = 2, ParentId = 7, Name = "Линейные и сводимые к ним уравнения" },
            new { Id = ++i, DisplayId = 3, ParentId = 7, Name = "Дробно-рациональные уравнения" },
            new { Id = ++i, DisplayId = 4, ParentId = 7, Name = "Иррациональные уравнения" },
            new { Id = ++i, DisplayId = 5, ParentId = 7, Name = "Показательные уравнения" },
            new { Id = ++i, DisplayId = 6, ParentId = 7, Name = "Логарифмические уравнения" },
            new { Id = ++i, DisplayId = 7, ParentId = 7, Name = "Степенные уравнения" },
            new { Id = ++i, DisplayId = 1, ParentId = 8, Name = "Прямоугольные треугольник" },
            new { Id = ++i, DisplayId = 2, ParentId = 8, Name = "Равнобедренные треугольники" },
            new { Id = ++i, DisplayId = 1, ParentId = 9, Name = "Производная и функция" },
            new { Id = ++i, DisplayId = 2, ParentId = 9, Name = "Графиики и диаграммы" },
            new { Id = ++i, DisplayId = 3, ParentId = 9, Name = "Графики функций и их уравнения" },
            new { Id = ++i, DisplayId = 4, ParentId = 9, Name = "Квадратичные функции" },
            new { Id = ++i, DisplayId = 5, ParentId = 9, Name = "Функции" },
            new { Id = ++i, DisplayId = 1, ParentId = 10, Name = "Составные многогранники" },
            new { Id = ++i, DisplayId = 2, ParentId = 10, Name = "Прямоугольный параллелепипед" },
            new { Id = ++i, DisplayId = 3, ParentId = 10, Name = "Пирамида" },
            new { Id = ++i, DisplayId = 4, ParentId = 10, Name = "Конус" },
            new { Id = ++i, DisplayId = 5, ParentId = 10, Name = "Цилиндр" },
            new { Id = ++i, DisplayId = 6, ParentId = 10, Name = "Шар" },
            new { Id = ++i, DisplayId = 7, ParentId = 10, Name = "Комбинации тел" },
            new { Id = ++i, DisplayId = 8, ParentId = 10, Name = "Призма" },
            new { Id = ++i, DisplayId = 1, ParentId = 11, Name = "Выбор оптимального варианта" },
            new { Id = ++i, DisplayId = 1, ParentId = 12, Name = "Показательные неравенства" },
            new { Id = ++i, DisplayId = 2, ParentId = 12, Name = "Квадратичные неравенства и МИ" },
            new { Id = ++i, DisplayId = 3, ParentId = 12, Name = "Неравенства разных видов" },
            new { Id = ++i, DisplayId = 4, ParentId = 12, Name = "Логарифмические неравенства" },
            new { Id = ++i, DisplayId = 5, ParentId = 12, Name = "Точки" },
            new { Id = ++i, DisplayId = 1, ParentId = 13, Name = "Рациональные выражения" },
            new { Id = ++i, DisplayId = 2, ParentId = 13, Name = "Иррациональные выражения" },
            new { Id = ++i, DisplayId = 3, ParentId = 13, Name = "Тригонометрические выражения" },
            new { Id = ++i, DisplayId = 4, ParentId = 13, Name = "Логарифмические выражения" },
            new { Id = ++i, DisplayId = 5, ParentId = 13, Name = "Степенные выражения" },
            new { Id = ++i, DisplayId = 1, ParentId = 14, Name = "Параллелепипед" },
            new { Id = ++i, DisplayId = 2, ParentId = 14, Name = "Призма" },
            new { Id = ++i, DisplayId = 3, ParentId = 14, Name = "Пирамида" },
            new { Id = ++i, DisplayId = 4, ParentId = 14, Name = "Цилиндр" },
            new { Id = ++i, DisplayId = 5, ParentId = 14, Name = "Конус" },
            new { Id = ++i, DisplayId = 6, ParentId = 14, Name = "Комбинация тел" },
            new { Id = ++i, DisplayId = 1, ParentId = 15, Name = "Рациональные функции" },
            new { Id = ++i, DisplayId = 2, ParentId = 15, Name = "Логарифмические функции" },
            new { Id = ++i, DisplayId = 3, ParentId = 15, Name = "Показательные функции" },
            new { Id = ++i, DisplayId = 4, ParentId = 15, Name = "Тригонометрические функции" },
            new { Id = ++i, DisplayId = 5, ParentId = 15, Name = "Иррациональные функции" },
            new { Id = ++i, DisplayId = 1, ParentId = 16, Name = "Задачи на смеси и сплавы" },
            new { Id = ++i, DisplayId = 2, ParentId = 16, Name = "Задачи на движение" },
            new { Id = ++i, DisplayId = 3, ParentId = 16, Name = "Задачи на движение по реке" },
            new { Id = ++i, DisplayId = 4, ParentId = 16, Name = "Задачи на работу" },
            new { Id = ++i, DisplayId = 5, ParentId = 16, Name = "Задачи на арифметическую прогрессию" },
            new { Id = ++i, DisplayId = 6, ParentId = 16, Name = "Задачи на процентное содержание сухого вещества" },
            new { Id = ++i, DisplayId = 7, ParentId = 16, Name = "Сложные проценты" },
            new { Id = ++i, DisplayId = 8, ParentId = 16, Name = "Движение по кругу" },
            new { Id = ++i, DisplayId = 1, ParentId = 17, Name = "Тригонометрические уравнения" },
            new { Id = ++i, DisplayId = 2, ParentId = 17, Name = "Показательные уравнения" },
            new { Id = ++i, DisplayId = 3, ParentId = 17, Name = "Логарифмические уравнения" },
            new { Id = ++i, DisplayId = 4, ParentId = 17, Name = "Иррациональные уравнения" },
            new { Id = ++i, DisplayId = 5, ParentId = 17, Name = "Дробно рациональные уравнения" },
            new { Id = ++i, DisplayId = 1, ParentId = 18, Name = "Угол между плоскостью и прямой" },
            new { Id = ++i, DisplayId = 2, ParentId = 18, Name = "Угол между плоскостями" },
            new { Id = ++i, DisplayId = 3, ParentId = 18, Name = "Угол между прямыми" },
            new { Id = ++i, DisplayId = 4, ParentId = 18, Name = "Расстояние от точки до прямой" },
            new { Id = ++i, DisplayId = 5, ParentId = 18, Name = "Расстояние от точки до плоскости" },
            new { Id = ++i, DisplayId = 1, ParentId = 19, Name = "Логарифмическое и показательное неравенства" },
            new { Id = ++i, DisplayId = 2, ParentId = 19, Name = "Логарифмическое и дробно-рациональное неравенство" },
            new { Id = ++i, DisplayId = 3, ParentId = 19, Name = "Показательное и дробно-рациональное неравенство" },
            new { Id = ++i, DisplayId = 4, ParentId = 19, Name = "Логарифмические неравенства" },
            new { Id = ++i, DisplayId = 5, ParentId = 19, Name = "Показательные неравенства" },
            new { Id = ++i, DisplayId = 1, ParentId = 20, Name = "Планиметрические задачи" },
            new { Id = ++i, DisplayId = 1, ParentId = 21, Name = "Уравнения с параметром" },
            new { Id = ++i, DisplayId = 2, ParentId = 21, Name = "Системы уравнений с парметром" },
            new { Id = ++i, DisplayId = 3, ParentId = 21, Name = "Неравенства с параметром" },
            new { Id = ++i, DisplayId = 4, ParentId = 21, Name = "Системы неравенств с параметром" },
        };

        modelBuilder
            .Entity<SubCategory>()
            .HasData(subCategory);
    }

    private static void BuildCategory(ModelBuilder modelBuilder)
    {
        modelBuilder
            .Entity<Category>()
            .HasKey(x => x.Id);

        var i = 0;
        var categories = new object[]
        {
            new { Id = ++i, Name = "Простейшие задачи" },
            new { Id = ++i, Name = "Задачи на проценты" },
            new { Id = ++i, Name = "Чтение графиков и диаграмм" },
            new { Id = ++i, Name = "Работа с формулами" },
            new { Id = ++i, Name = "Квадратная решетка, координатная плоскость" },
            new { Id = ++i, Name = "Начала теории вероятностей" },
            new { Id = ++i, Name = "Простейшие уравнения" },
            new { Id = ++i, Name = "Планиметрия: задачи, связанные с углами" },
            new { Id = ++i, Name = "Анализ графиков и диаграмм" },
            new { Id = ++i, Name = "Стереометрия" },
            new { Id = ++i, Name = "Выбор оптимального варианта" },
            new { Id = ++i, Name = "Простейшие неравенства" },
            new { Id = ++i, Name = "Вычисления и преобразования" },
            new { Id = ++i, Name = "Стереометрия" },
            new { Id = ++i, Name = "Наибольшее и наименьшее значение функции" },
            new { Id = ++i, Name = "Текстовые задачи" },
            new { Id = ++i, Name = "Уравнения, системы уравнений" },
            new { Id = ++i, Name = "Углы и расстояния в пространстве" },
            new { Id = ++i, Name = "Неравенства, системы неравенств" },
            new { Id = ++i, Name = "Планиметрические задачи" },
            new { Id = ++i, Name = "Уравнения, неравенства и их системы с параметрами" }
        };

        modelBuilder
            .Entity<Category>()
            .HasData(categories);
    }
}
